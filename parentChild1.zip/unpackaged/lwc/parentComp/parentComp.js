import { LightningElement } from 'lwc';

export default class ParentComp extends LightningElement {
    handleChangeEvent(event){
        if (event.target.label === 'Name') {
            this.template.querySelector('c-child-Comp').changeMessage(event.target.value);
        }
        
        if (event.target.label === 'Record #') {
            this.template.querySelector('c-child-Comp').changeMessage1(event.target.value);
        }
        
    }
    searchName(){
        this.template.querySelector("c-child-Comp").showMsg();
    }
}