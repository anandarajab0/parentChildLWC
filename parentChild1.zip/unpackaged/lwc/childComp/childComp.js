import { LightningElement,track,api } from 'lwc';
import getAccountList from '@salesforce/apex/searchRecord.search';

export default class ChildComp extends LightningElement {
   @track accounts;
   @track filterData;
   @track filterData1;
   @track nameVal;
   @track limitVal;  
   @track finalMsg;
   @track dataArray=[];
   @track item={};

   @track j = 0;
   @track showFilterData = false;
   handleChange(event){
        this.filterData = event.target.value;
   }
    @api
    changeMessage(strString) {
         this.nameVal = strString;
    }
    @api
    changeMessage1(strString) {  
        this.limitVal = strString;
   }
   @api
   showMsg() {  
    this.showFilterData = false;
    this.accounts = null;
    this.dataArray = [];
    this.finalMsg = this.nameVal+' - '+this.limitVal;
       console.log('entered name ==>>>'+this.nameVal);
       console.log('entered limit==>>>'+this.limitVal);
      getAccountList({LimitRec : this.limitVal,searchName : this.nameVal})
      .then(result => {
          this.accounts = result;
          console.log('result===>>>'+result);
          var abc = JSON.stringify(this.accounts);
          console.log('abc===>>'+abc);
      })
      .catch(error => {
          this.error = error;
      });
  }

filterData12(){
    
    if(this.filterData!=null){
    
    this.showFilterData = true;
    this.dataArray = [];
    console.log('entered filterData ==>>'+this.filterData);
    console.log('entered accounts ==>>'+this.accounts);
    var abc = JSON.stringify(this.accounts);
    console.log('accounts1 ==>>'+this.abc);



for(var i = 0; i < this.accounts.length; i++) {
    this.item={};
    if ((this.accounts[i].Name).toLowerCase().includes(this.filterData.toLowerCase())){
        console.log('i===>>>'+this.i);
        this.item["Id"] = this.i;
        this.item["Name"] = (this.accounts[i].Name);
        console.log('name===>>>'+this.accounts[i].Name);
        this.dataArray.push(this.item);
        
    }else{
        console.log('false');
        
    }
    
}
console.log('dataArray==>>'+this.dataArray);   
var abc = this.dataArray;
console.log('dataArray==>>'+JSON.stringify(this.dataArray));   
}
}
}