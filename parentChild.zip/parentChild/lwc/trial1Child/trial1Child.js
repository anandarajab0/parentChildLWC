import { LightningElement,api } from 'lwc';

export default class Trial1Child extends LightningElement {
    @api account ;

}